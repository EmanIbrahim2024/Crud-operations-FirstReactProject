import React from "react";
import Container from "react-bootstrap/Container";

function AboutUs() {
  return (
    <>
      <Container>
        <p>Hello from AboutUs</p>
      </Container>
    </>
  );
}

export default AboutUs;
