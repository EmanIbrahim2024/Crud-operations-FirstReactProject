import React from "react";
import Container from "react-bootstrap/Container";
function ContactUs() {
  return (
    <>
      <Container>
        <p>Hello from ContactUs</p>
      </Container>
    </>
  );
}

export default ContactUs;
