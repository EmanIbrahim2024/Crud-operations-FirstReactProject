What’s CSS ?
- make a full layout using html - css [with float] "
- flex 
- make a full layout using html - css [with flex] "
- Media Queries
- variables in css
- Transition, 
align-self: stretch;
flex-basis: 200px; 
- Grid
- make a full layout using html - css grid [with Grid]
- filters
- gradients
/*****************************/



- CSS Selectors
- 2D and 3D transformation
- Animation
- CSS Global Values


