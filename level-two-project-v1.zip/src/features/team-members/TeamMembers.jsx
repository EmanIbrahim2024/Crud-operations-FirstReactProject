import React from "react";

function TeamMembers() {
  return (
    <div>
      <h1>Team Members</h1>
    </div>
  );
}

export default TeamMembers;
