import React from 'react'
import './style.css'
function Footer() {
  return (
    <div className='footer'>
      <p>All Copy right Saved @ 2024</p>
    </div>
  )
}
export default Footer
