import axios from "axios";
import { createAsyncThunk } from "@reduxjs/toolkit";

// fetch all posts
export const fetchPosts = createAsyncThunk("posts/fetchPosts", async () => {
  const response = await axios.get("https://jsonplaceholder.typicode.com/posts");
  return response.data;
});

// add new posts
export const addPost = createAsyncThunk("posts/addPost", async (postData) => {
    const response = await axios.post("https://jsonplaceholder.typicode.com/posts", postData);
    return response.data;
});

// delete post 
export const deletePost = createAsyncThunk("posts/deletePost", async (postId) => {
    const response = await axios.delete("https://jsonplaceholder.typicode.com/posts", postId);
    return response.data;
});