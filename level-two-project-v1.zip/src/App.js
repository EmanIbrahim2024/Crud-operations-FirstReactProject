import React from 'react';
import Header from './shared/header/Header';
import Footer from './shared/footer/Footer';

function App() {
  return (
    <div className="App">
      <Header />
      <Footer />
    </div>
  );
}

export default App;
